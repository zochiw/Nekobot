cogs_path = "/home/tintin/discord_bot/NekoBot/cogs/"
data_path = "/home/tintin/discord_bot/NekoBot/data/"
web_path = "/var/www/html/images/"

kiri_path = "/home/tintin/discord_bot/Kiri-Chan/"